package com.ecomobile.photo_cutter

import com.ecomobile.photo_cutter.model.CutType
import com.ecomobile.photo_cutter.model.FreedomCutterAnimationMode

open class FreedomCutterCallbackImpl {
    open fun onChangeVersion(currentVersion: Int, totalVersion: Int) {}
    open fun onChangeType(type: CutType) {}
    open fun onAICutCompleted(success: Boolean) {}
    open fun onCenterModeChanged(mode: FreedomCutterAnimationMode) {}
}